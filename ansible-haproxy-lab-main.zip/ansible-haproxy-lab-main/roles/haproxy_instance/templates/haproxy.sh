#!/bin/sh
#
# haproxy         starting and stopping the haproxy load balancer
# chkconfig: 345 55 45
# description: haproxy is a TCP/HTTP load‑balancer
# probe: true

. /etc/rc.d/init.d/functions
. /etc/sysconfig/network

NAME=haproxy
DAEMON=/usr/sbin/${NAME}
CONFIG_DIR={{ instance_directory }}

[ "$NETWORKING" = "no" ] && exit 0
[ -f $DAEMON ] || { echo "No haproxy installed!"; exit 0; }
[ -f $CONFIG_DIR/haproxy.cfg ] || exit 0

checkconfig() {
    $DAEMON -c -q -f $CONFIG_DIR/haproxy.cfg
    return $?
}

start() {
    checkconfig || { echo "Errors in configuration."; return 1; }
    echo -n "Starting HAProxy: "
    daemon $DAEMON -D -f $CONFIG_DIR/haproxy.cfg -p $CONFIG_DIR/haproxy.pid
    RETVAL=$?
    echo
    [ $RETVAL -eq 0 ] && touch $CONFIG_DIR/haproxy
    return $RETVAL
}

stop() {
    echo -n "Shutting down HAProxy: "
    killproc -p $CONFIG_DIR/haproxy.pid haproxy
    RETVAL=$?
    echo
    [ $RETVAL -eq 0 ] && rm -f $CONFIG_DIR/haproxy $CONFIG_DIR/haproxy.pid
    return $RETVAL
}

restart() {
    checkconfig || { echo "Errors in configuration."; return 1; }
    stop
    start
}

reload() {
    checkconfig || { echo "Errors in configuration."; return 1; }
    echo -n "Reloading HAProxy config: "
    $DAEMON -D -f $CONFIG_DIR/haproxy.cfg -p $CONFIG_DIR/haproxy.pid -sf $(cat $CONFIG_DIR/haproxy.pid)
    success "Reloading HAProxy config: "
    echo
}

statushaproxy() {
    status haproxy
}

case "$1" in
    start)
        start;;
    stop)
        stop;;
    restart)
        restart;;
    reload)
        reload;;
    status)
        statushaproxy;;
    checkconfig)
        checkconfig;;
    *)
        echo "Usage: haproxy {start|stop|status|restart|reload|checkconfig}"
        exit 1;;
esac

exit 0