#!/bin/bash
{{ instance_directory }}/haproxy.sh stop
ERROR=$?
pid=$( ps -elf | grep haproxy | grep '{{ instance_directory }}' | awk '$5 == 1 {print $4}' )
if [[ $ERROR -ne 0 && -n "$pid" ]]; then
  kill -9 -${pid}
fi
