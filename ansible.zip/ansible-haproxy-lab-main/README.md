```markdown
# HAProxy Ansible Assessment (Senior)

This repository contains a purposely messy HAProxy role that needs improvement. Your mission is to analyze its tag flow and refactor the start/stop logic, then improve it as you see fit.

## Quick Start
1. Install VirtualBox 7.x and Vagrant 2.4.x (defaults are fine).
2. Clone this repo and `cd` into it.
3. `vagrant up && vagrant ssh`.
4. Inside the VM: `cd /vagrant && ANSIBLE_ROLES_PATH=/vagrant/roles ansible-playbook -i inventory/hosts playbooks/deploy_haproxy.yml`.
5. Browse `http://localhost:50032/stats?stats` – you should see the HAProxy stats page.

### Hint
The legacy start/stop scripts expect to run under the **sslsrv** account and to be able to create a PID file inside the instance directory.  
Anything else will exit with an error — feel free to fix that in any clean way (`become_user`, proper file ownership, or replacing the scripts with a systemd handler).

## Core Requirements

1. **Task Flow Analysis** – Run `ansible-playbook playbooks/deploy_haproxy.yml --tags stop,clean,deploy,start --check` and provide a detailed explanation of which tasks run and why.

2. **Basic Refactoring** – Replace the shell-script start/stop with the `service` module and add a handler that reloads HAProxy when the config template changes.

## Additional Challenge

Beyond the core requirements, you have complete freedom to improve this HAProxy role as you see fit. Show us your expertise by implementing changes that demonstrate your skills and understanding of DevOps best practices.

## Deliverables

1. Working code for all implemented improvements
2. A comprehensive `ANSWER.md` file at the repo root explaining:
   - Your task flow analysis
   - What improvements you made and why
   - How you would measure the success of your changes
   - What further improvements you would recommend if you had more time

You have 24 hours to complete this assessment. We value quality over quantity, and we're interested in your approach to solving real-world infrastructure challenges.

Good luck!
```