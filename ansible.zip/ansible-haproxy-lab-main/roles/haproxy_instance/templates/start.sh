#!/bin/bash
if [ "$(id -u)" == "0" ]; then
  echo "please don't run this script as root user"
  exit 1
fi

cd {{ instance_directory }}

{{ instance_directory }}/haproxy.sh start
