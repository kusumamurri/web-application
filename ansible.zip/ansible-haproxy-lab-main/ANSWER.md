File: prepare_haproxy.yml
	task: Deploy legacy control scripts
	change: need to modify file permissions from 750 to 755; because as the file is owned by root ; the user sslsrv doesnt have execute permissions to start or stop. So we have to give permissions for others.

File: stop_start.yml
	task: Start the application via legacy script
	Change: need to add become and become_user because only sslsrv can do it ; not the root user.

The above changes are no longer required when we implement the service with systemd handler.

We need to add haproxy service file in the roles/role_name/templates
and then copy to desired location i.e,. /etc/systemd/system/service_name.service & then reload the service.

when this service is implemented via systemd handler, there is no need to check the "pid_file_check_result".

start & stop of the service can be implemented via service module in ansible without executing shell scripts.
So we can remove shell scripts from the templates section & comment out copying of files to the respective directory in prepare_haproxy.yml file.

We also dont need pre_tasks.yml file  & we can comment out the task in yaml file where it is importing the task.



**Task Flow Analysis**

ANSIBLE_ROLES_PATH=/vagrant/roles ansible-playbook -i inventory/hosts playbooks/deploy_haproxy.yml

The tasks in deploy_haproxy.yml will be executed.
in this yaml file , there are pre_tasks and roles. So pre_tasks will be executed before the roles.

. After installing haproxy & ensuring sslsrv user ; the ansible role will be called.
. When the role is called , it will execute the tasks in roles/role_name/tasks/main.yml
. it will use the variables in defaults folder.
. when the main.yml file is called from tasks folder , it will execute the tasks in the yaml file.
. tasks are defined along with tags.When we give tags while running ansible command, only that specific task will run.
. Stop application task will be executed only when the tags never, stop, clean, deploy are mentioned.
. When we specify tag "stop" in the command , then it will execute stop_application task , which will execute stop_start.yml file with variable haproxy_stop: true 
	. It will execute the task "Stop running application" since there is condition when haproxy_stop
	. And it has register to record the service status
	. Other tasks will be skipped because it doesnt satisfy the condition
. When "start" tag is specified , it will execute "Start the application via legacy script" and the later steps will also be executed (Wait for HAProxy port & Wait for stats page 200) because the service_start_state is changed.
. When the tag "deploy" is specified , in thr main.yml file the task"Stop application" task & "Configure application" is executed and the tasks in prepare_haproxy.yml will be executed. 





